const Info = () => {
    return (
        <div className={'col-sm-5 info'}>
            <h1>Weather application</h1>
            <p>Your city weather</p>
        </div>
    );
};

export default Info;