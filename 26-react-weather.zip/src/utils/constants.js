export const base_url = `https://api.openweathermap.org/data/2.5/weather`;
export const api_key = `d6ca400b920aa035dbe5c7b7ab6561d3`;
export const weather_cache_time = 60 * 1000;